"""iobs_ngc – Python package for non-graphitic carbon scattering calculations."""


# start delvewheel patch
def _delvewheel_patch_1_13_0():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'iobs_ngc.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_0()
del _delvewheel_patch_1_13_0
# end delvewheel patch

# Re-export the compiled extension symbols
from .iobs_ngc import (   # noqa: F401
    IOBSParameters,
    IOBSCalculator,
    Calculations,
    RadiationType,
    CSP,
)

from .fitter import IOBSFitter, FitResult, StageResult   # noqa: F401
from .parameter_bounds import (                          # noqa: F401
    DEFAULT_PARAM_BOUNDS,
    DEFAULT_STAGE_DEFINITIONS,
)

from .utils import FitPattern, microstructure_report     # noqa: F401
